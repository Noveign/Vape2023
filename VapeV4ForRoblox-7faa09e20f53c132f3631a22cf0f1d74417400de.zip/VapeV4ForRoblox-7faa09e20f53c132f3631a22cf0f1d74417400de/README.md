# Vape V4
**A script that I have maintained for 5 years, mostly known for bedwars.**

I will not allow selling my code in any capacity, this mean's customs that profit off of my work.
